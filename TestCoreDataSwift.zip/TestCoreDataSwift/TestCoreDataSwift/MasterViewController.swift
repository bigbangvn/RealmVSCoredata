//
//  MasterViewController.swift
//  TestCoreDataSwift
//
//  Created by Nguyen Trong Bang on 13/10/17.
//  Copyright © 2017 Nguyen Trong Bang. All rights reserved.
//

import UIKit
import CoreData

let NUM_OBJECT_INSERT = 10000

class MasterViewController: UITableViewController, NSFetchedResultsControllerDelegate {

    var detailViewController: DetailViewController? = nil
    var managedObjectContext: NSManagedObjectContext? = nil


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem

        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        navigationItem.rightBarButtonItem = addButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        deleteAllRecords()
        testInsertToDB()
    }
    
    func deleteAllRecords() {
        print("DELETE ALL RECORDS")
        let context = self.fetchedResultsController.managedObjectContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Event")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            print ("There was an error")
        }
    }
    
    func testInsertToDB() {
        print("START INSERT DATA")
        var startTime = CFAbsoluteTimeGetCurrent()
        let context = self.fetchedResultsController.managedObjectContext
        let arr: NSMutableArray = NSMutableArray()
        for _ in 0..<NUM_OBJECT_INSERT {
            let event = Event(context: context)
            event.timestamp = Date()
            event.name = "Item Name"
            event.name1 = "Item Name"
            event.name2 = "Item Name"
            event.name3 = "Item Name"
            event.name4 = "Item Name"
            event.name5 = "Item Name"
            event.name6 = "Item Name"
            event.name7 = "Item Name"
            event.name8 = "Item Name"
            event.name9 = "Item Name"
            event.name10 = "Item Name"
            arr.add(event)
        }
        do {
            try context.save()
        } catch {
            print("Error: \(error)")
        }
        print("FINISHED INSERT: \(CFAbsoluteTimeGetCurrent() - startTime)")
        startTime = CFAbsoluteTimeGetCurrent()
        let str: NSMutableString = NSMutableString()
        for i in 0..<NUM_OBJECT_INSERT {
            let event = self.fetchedResultsController.object(at: IndexPath(row: i, section: 0))
            str.append(event.name!)
        }
        
        let md5Data = MD5(string: str as String)
        let md5Hex =  md5Data.map { String(format: "%02hhx", $0) }.joined()
        
        print("Read string md5: \(md5Hex) len: \(str.length)")
        print("FINISHED READ: \(CFAbsoluteTimeGetCurrent() - startTime)")
    }
    
    func MD5(string: String) -> Data {
        let messageData = string.data(using:.utf8)!
        var digestData = Data(count: Int(CC_MD5_DIGEST_LENGTH))
        
        _ = digestData.withUnsafeMutableBytes {digestBytes in
            messageData.withUnsafeBytes {messageBytes in
                CC_MD5(messageBytes, CC_LONG(messageData.count), digestBytes)
            }
        }
        
        return digestData
    }
    
    func allocUntilDie() {
        print("START ALLOC...")
        var numMB: Int = 0;
        while true {
            allocateMemoryOfSize2(numberOfMegaBytes: 2)
            numMB += 2
            print("Allocated: \(numMB) MB")
        }
    }
    
    //It's quite slow to allocate heap in Swift
    //Call after write & read DB, to check how mem cache work
    func allocateMemoryOfSize(numberOfMegaBytes: Int) {
        print("Allocating \(numberOfMegaBytes)MB of memory")
        let mb = 1048576
        let numberOfBytes = numberOfMegaBytes * mb
        var newBuffer = [UInt8](repeating: 0, count: numberOfBytes)
        
        for i in 0 ..< numberOfBytes {
            newBuffer[i] = UInt8(i % 7)
        }
        print("Finished allocating")
    }

    //It's slow too
    //https://developer.apple.com/documentation/swift/unsaferawpointer
    func allocateMemoryOfSize2(numberOfMegaBytes: Int) {
        let mb = 1048576
        let bufferSize = Int(numberOfMegaBytes * mb)
        let bytesPointer = UnsafeMutableRawPointer.allocate(bytes: bufferSize, alignedTo: 1)
        
        for i in 0...(bufferSize-1) {
            let offsetPointer = bytesPointer + 2
            //offsetPointer.storeBytes(of: i, as: UInt8.self)
            let y = offsetPointer.load(as: UInt8.self)
        }
    }
    
    @objc
    func insertNewObject(_ sender: Any) {
        let context = self.fetchedResultsController.managedObjectContext
        let newEvent = Event(context: context)
             
        // If appropriate, configure the new managed object.
        newEvent.timestamp = Date()

        // Save the context.
        do {
            try context.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
            let object = fetchedResultsController.object(at: indexPath)
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = object
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Fetched results controller

    var fetchedResultsController: NSFetchedResultsController<Event> {
        if _fetchedResultsController != nil {
            return _fetchedResultsController!
        }
        
        let fetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
        
        // Set the batch size to a suitable number.
        fetchRequest.fetchBatchSize = 20
        
        // Edit the sort key as appropriate.
        let sortDescriptor = NSSortDescriptor(key: "timestamp", ascending: false)
        
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        // Edit the section name key path and cache name if appropriate.
        // nil for section name key path means "no sections".
        let aFetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: self.managedObjectContext!, sectionNameKeyPath: nil, cacheName: "Master")
        aFetchedResultsController.delegate = self
        _fetchedResultsController = aFetchedResultsController
        
        do {
            try _fetchedResultsController!.performFetch()
        } catch {
             // Replace this implementation with code to handle the error appropriately.
             // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. 
             let nserror = error as NSError
             fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        
        return _fetchedResultsController!
    }    
    var _fetchedResultsController: NSFetchedResultsController<Event>? = nil

    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        //tableView.beginUpdates()
    }

    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
//        switch type {
//            case .insert:
//                tableView.insertSections(IndexSet(integer: sectionIndex), with: .fade)
//            case .delete:
//                tableView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
//            default:
//                return
//        }
    }

    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
//        switch type {
//            case .insert:
//                tableView.insertRows(at: [newIndexPath!], with: .fade)
//            case .delete:
//                tableView.deleteRows(at: [indexPath!], with: .fade)
//            case .update:
//                configureCell(tableView.cellForRow(at: indexPath!)!, withEvent: anObject as! Event)
//            case .move:
//                configureCell(tableView.cellForRow(at: indexPath!)!, withEvent: anObject as! Event)
//                tableView.moveRow(at: indexPath!, to: newIndexPath!)
//        }
    }

    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
//        tableView.endUpdates()
    }
}

