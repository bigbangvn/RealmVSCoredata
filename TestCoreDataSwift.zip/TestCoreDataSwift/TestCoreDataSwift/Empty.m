//
//  Empty.m
//  TestCoreDataSwift
//
//  Created by Nguyen Trong Bang on 11/11/17.
//  Copyright © 2017 Nguyen Trong Bang. All rights reserved.
//

#import "Empty.h"

@implementation Empty

@end
