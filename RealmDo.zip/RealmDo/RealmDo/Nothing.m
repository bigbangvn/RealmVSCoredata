//
//  Nothing.m
//  RealmDo
//
//  Created by Nguyen Trong Bang on 11/11/17.
//  Copyright © 2017 Nguyen Trong Bang. All rights reserved.
//

#import "Nothing.h"

@implementation Nothing

@end
