//
//  Reminder.swift
//  RealmDo
//
//  Created by Nguyen Trong Bang on 9/10/17.
//  Copyright © 2017 Nguyen Trong Bang. All rights reserved.
//

import UIKit
import RealmSwift

class Reminder: Object {
    @objc dynamic var name = ""
    @objc dynamic var name1 = ""
    @objc dynamic var name2 = ""
    @objc dynamic var name3 = ""
    @objc dynamic var name4 = ""
    @objc dynamic var name5 = ""
    @objc dynamic var name6 = ""
    @objc dynamic var name7 = ""
    @objc dynamic var name8 = ""
    @objc dynamic var name9 = ""
    @objc dynamic var name10 = ""
    @objc dynamic var done = false
    @objc dynamic var date: Date = Date()
}
